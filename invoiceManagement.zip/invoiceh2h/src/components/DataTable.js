import React from "react";
import { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import axios from "axios";
import { TextField } from "@material-ui/core";
import { Button, Box, ButtonGroup } from "@material-ui/core";
import RefreshIcon from "@mui/icons-material/Refresh";
import AddDialog from "./AddDialog";

import { makeStyles } from "@material-ui/core";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@mui/material";
import EditInvoice from "./EditInvoice";
const DataTable = (props) => {
  const columns = [
    { field: "sl_no", headerName: "sl_no", width: 120 },
    {
      field: "business_code",
      headerName: "Business Code",
      width: 200,
    },
    {
      field: "cust_number",
      headerName: "Customer Number",
      width: 200,
    },
    {
      field: "clear_date",
      headerName: "Clear Date",
      width: 200,
    },

    {
      field: "buisness_year",
      headerName: "Business Year",
      width: 200,
    },
    {
      field: "doc_id",
      headerName: "Doc Id",
      width: 200,
    },
    {
      field: "posting_date",
      headerName: "Posting Date",
      width: 200,
    },
    {
      field: "document_create_date",
      headerName: "Document_Create_Date",
      width: 200,
    },
    {
      field: "document_create_date1",
      headerName: "document_create_date1",
      width: 200,
    },
    {
      field: "due_in_date",
      headerName: "Due Date",
      width: 200,
    },
    {
      field: "invoice_currency",
      headerName: "Invoice Currency",
      width: 200,
    },
    {
      field: "document_type",
      headerName: "Document Type",
      width: 200,
    },
    {
      field: "posting_id",
      headerName: "Posting Id",
      width: 200,
    },
    {
      field: "area_business",
      headerName: "Area Business",
      width: 200,
    },
    {
      field: "total_open_amount",
      headerName: "Total open amount",
      width: 200,
    },
    {
      field: "baseline_create_date",
      headerName: "Baseline Date",
      width: 200,
    },
    {
      field: "cust_payment_terms",
      headerName: "Cust paymentTerms",
      width: 200,
    },
    {
      field: "invoice_id",
      headerName: "Invoice Id",
      width: 200,
    },
    {
      field: "isOpen",
      headerName: "isOpen",
      width: 200,
    },

    {
      field: "aging_bucket",
      headerName: "Aging bucket",
      width: 200,
    },
    {
      field: "is_deleted",
      headerName: "isDeleted",
      width: 200,
    },
  ];

  const [openAdd, setOpenAdd] = React.useState(false);
  const [openDel, setOpenDel] = React.useState(false);
  const [openAdv, setOpenAdv] = React.useState(false);

  const handleCloseDel = () => setOpenDel(false);
  const handleCloseAdv = () => setOpenAdv(false);

  const addClick = () => setOpenAdd(false);
  const handleCloseAdd = () => setOpenAdd(false);
  const [invoicecurrency, setinvoicecurrency] = useState("");
  const [customerpaymentterms, setcustomerpaymentterms] = useState("");

  const [arrsl_no, setArrsl_no] = useState([]);
  const sl_no = arrsl_no[0];
  const handleDeleteAll = () => {
    console.log(arrsl_no);
    setOpenDel(false);
    axios
      .get(`http://localhost:8001/practiceProject/DeleteInvoice`, {
        params: { sl_no },
      })
      .then((data) => {
        console.log(data);
      })
      .catch((err) => alert(err));
  };

  const EditData = () => {
    setOpenAdd(false);
    axios.get(`http://localhost:8001/practiceProject/EditInvoice`, {
      params: {
        invoicecurrency,
        customerpaymentterms,
        sl_no,
      },
    });
  };

  const [documentId, setDocumentId] = useState("");
  const [invoiceId, setInvoiceId] = useState("");
  const [customerNumber, setcustomerNumber] = useState("");
  const [businessYear, setBusinessYear] = useState("");

  const handleSubmitAdv = async () => {
    let response = await axios({
      method: "GET",
      url: "http://localhost:8001/practiceProject/AdvanceSearch",
      params: {
       documentId:documentId,
       invoiceId: invoiceId,
       customerNumber:customerNumber,
       businessYear:businessYear,
      },
    });
    console.log(response.data);
    setOpenAdv(false);
    setData(response);
  };

{/*  const postData = () => {
    setOpenAdv(false);
    axios
      .get(`http://localhost:8001/practiceProject/AdvanceSearch`, {
        params: {
          documentId,
          invoiceId,
          customerNumber,
          businessYear,
        },
      })
  }; */}

    
   {/* useEffect(() => {
      fetch(`http://localhost:8001/practiceProject/AdvanceSearch?
      documentId=${documentId}&invoiceId=${invoiceId}&customerNumber=${customerNumber}&businessYear=${businessYear}`)
      .then((resp) => resp.json())
      .then((resp) => {
        setData(resp);
      });
        
    }, [documentId,invoiceId,customerNumber,businessYear]);*/}
  

  const useStyle = makeStyles({
    field: {
      marginTop: 10,
      marginBottom: 10,
      width: 500,
      padding: "5px",
      margin: "5px",
    },
    input: {
      background: "rgb(232, 241, 250)",
      "&:hover": {
        background: "rgb(232, 241, 250)",
      },
    },
  });
  const classes = useStyle();

  const [data, setData] = useState([]);
  useEffect(() => {
    fetch("http://localhost:8001/practiceProject/fetchdata")
      .then((resp) => resp.json())
      .then((resp) => {
        setData(resp);
      });
  }, [data]);
  function refresh() {
		window.location.reload(false);
	}
  return (
    <div style={{ height: 700, width: "100%" }}>
      <div className="wrapper">
        <div className="button-container">
          <Box>
            <ButtonGroup
              variant="contained"
              aria-label="outlined primary button group"
            >
              <Button
                onClick={props.predictClick}
                variant="contained"
                color="primary"
                style={{ border: "2px solid #3f51b5", color: "white" }}
              >
                Predict
              </Button>
              {/* <AdvanceSearch /> */}
             <div>
                <Button
                  onClick={() => setOpenAdv(true)}
                  variant="outlined"
                  color="primary"
                  style={{ border: "2px solid #3f51b5", color: "white" }}
                >
                  Advance Search
                </Button>

                <form action="">
                  <Dialog
                    open={openAdv}
                    onClose={() => setOpenAdv(false)}
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "10vh",
                    }}
                  >
                    <DialogTitle
                      style={{ backgroundColor: "#39495e", color: "white" }}
                    >
                      ADVANCE SEARCH
                    </DialogTitle>
                    <DialogContent
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        backgroundColor: "#39495e",
                      }}
                    >
                      <div>
                        <div>
                          <TextField
                            margin="dense"
                            className={classes.field}
                            InputProps={{ className: classes.input }}
                            backgroundColor="white"
                            id="filled-basic"
                            label="DocumentId"
                            variant="filled"
                            name="doc_id"
                            style={{ width: 200 }}
                            value={documentId}
                            onChange={(e) => {
                              setDocumentId(e.target.value);
                            }}
                          />
                          <TextField
                            id="filled-basic"
                            InputProps={{ className: classes.input }}
                            className={classes.field}
                            label="InvoiceId"
                            variant="filled"
                            style={{ width: 200 }}
                            name="invoice_id"
                            value={invoiceId}
                            onChange={(e) => {
                              setInvoiceId(e.target.value);
                            }}
                          />
                        </div>
                        <div>
                          <TextField
                            id="filled-basic"
                            className={classes.field}
                            InputProps={{ className: classes.input }}
                            label="CustomerNumber"
                            variant="filled"
                            style={{ width: 200 }}
                            name="cust_number"
                            value={customerNumber}
                            onChange={(e) => {
                              setcustomerNumber(e.target.value);
                            }}
                          />

                          <TextField
                            id="filled-basic"
                            InputProps={{ className: classes.input }}
                            className={classes.field}
                            label="BusinessYear"
                            variant="filled"
                            style={{ width: 200 }}
                            name="buisness_year"
                            value={businessYear}
                            onChange={(e) => {
                              setBusinessYear(e.target.value);
                            }}
                          />
                        </div>
                      </div>
                    </DialogContent>
                    <DialogActions
                      style={{
                        display: "flex",
                        backgroundColor: "#39495e",
                        color: "white",
                        justifyContent: "center",
                      }}
                    >
                      <div className="dbtn">
                        <Button
                          style={{ width: 200 }}
                          variant="contained"
                          onClick={handleCloseAdv}
                        >
                          Cancel
                        </Button>
                        &nbsp;&nbsp;
                        <Button
                          onClick={handleSubmitAdv}
                          style={{ width: 200 }}
                          variant="contained"
                          type="submit"
                        >
                          Search
                        </Button>
                      </div>
                    </DialogActions>
                  </Dialog>
                </form>
              </div>
              <Button
                //onClick={props.predictClick}
                variant="outlined"
                color="primary"
                style={{ border: "2px solid #3f51b5", color: "white" }}
              >
                Analytics View
              </Button>
              <button variant="outlined" onClick={refresh}>
                <RefreshIcon />
              </button>
            </ButtonGroup>
          </Box>
          <div className="button-containerM">
            <TextField
              style={{ border: "2px solid", color: "white" }}
              label="Search invoice id"
              variant="filled"
              InputLabelProps={{ className: "field__lable" }}
            />
          </div>

          <AddDialog />
          {/*<DeleteInvoice />*/}
          <div>
            <Button
              onClick={() => setOpenDel(true)}
              variant="outlined"
              color="primary"
              style={{ border: "2px solid #3f51b5", color: "white" }}
            >
              Delete
            </Button>
            <Dialog
              open={openDel}
              onClose={() => setOpenDel(false)}
              style={{ display: "flex", flexDirection: "column", gap: "10vh" }}
            >
              <DialogTitle
                style={{ backgroundColor: "#39495e", color: "white" }}
              >
                Delete
              </DialogTitle>
              <DialogContent
                style={{
                  backgroundColor: "#39495e",
                }}
              >
                <DialogContentText
                  style={{ backgroundColor: "#39495e", color: "white" }}
                >
                  Are you sure, want to Delete?
                </DialogContentText>
              </DialogContent>
              <DialogActions
                style={{
                  display: "flex",
                  backgroundColor: "#39495e",
                  color: "white",
                  justifyContent: "center",
                }}
              >
                <div className="dbtn">
                  <Button
                    style={{ width: 200 }}
                    variant="contained"
                    onClick={handleCloseDel}
                  >
                    Cancel
                  </Button>
                  &nbsp;&nbsp;
                  <Button
                    onClick={handleDeleteAll}
                    style={{ width: 200 }}
                    variant="contained"
                    type="submit"
                  >
                    Delete
                  </Button>
                </div>
              </DialogActions>
            </Dialog>
          </div>

          {/* <EditInvoice/>*/}

          <div>
            <Button
              onClick={() => setOpenAdd(true)}
              color="primary"
              style={{
                width: "200",
                border: "2px solid #3f51b5",
                color: "white",
              }}
            >
              Edit
            </Button>
            <Dialog
              open={openAdd}
              onClose={() => setOpenAdd(false)}
              style={{ display: "flex", flexDirection: "column", gap: "10vh" }}
            >
              <DialogTitle
                style={{ backgroundColor: "#39495e", color: "white" }}
              >
                EDIT
              </DialogTitle>
              <DialogContent
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "10vh",
                  height: "80%",
                  backgroundColor: "#39495e",
                }}
              >
                <div>
                  <TextField
                    margin="dense"
                    className={classes.field}
                    InputProps={{ className: classes.input }}
                    backgroundColor="white"
                    id="filled-basic"
                    label="Invoice Currency"
                    variant="filled"
                    name="invoice_currency"
                    style={{ width: 200 }}
                    value={invoicecurrency}
                    onChange={(e) => {
                      setinvoicecurrency(e.target.value);
                    }}
                  />
                  <TextField
                    id="filled-basic"
                    className={classes.field}
                    InputProps={{ className: classes.input }}
                    label="Customer Payment Terms"
                    variant="filled"
                    style={{ width: 200 }}
                    name="cust_payment_terms"
                    value={customerpaymentterms}
                    onChange={(e) => {
                      setcustomerpaymentterms(e.target.value);
                    }}
                  />
                </div>
              </DialogContent>
              <DialogActions
                style={{
                  display: "flex",
                  backgroundColor: "#39495e",
                  color: "white",
                  justifyContent: "center",
                }}
              >
                <div className="dbtn">
                  <Button
                    style={{ width: 200 }}
                    variant="contained"
                    onClick={handleCloseAdd}
                  >
                    CANCLE
                  </Button>
                  &nbsp;&nbsp;
                  <Button
                    style={{ width: 200 }}
                    variant="contained"
                    type="submit"
                    onClick={EditData}
                  >
                    EDIT
                  </Button>
                </div>
              </DialogActions>
            </Dialog>
          </div>
        </div>
      </div>
      <DataGrid
        style={{ color: "white", width: "100%", height: "100%" }}
        columns={columns}
        rows={data}
        getRowId={(row) => row.sl_no}
        pageSize={10}
        checkboxSelection={true}
        onSelectionModelChange={(sl_no) => {
          setArrsl_no(sl_no);
        }}
        disableSelectionOnClick
      />
    </div>
  );
};
export default DataTable;
