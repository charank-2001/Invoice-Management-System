import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { makeStyles } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import axios from "axios";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@mui/material";



function DeleteInvoice() {
  const [openAdd, setOpenAdd] = React.useState(false);
  const addClick = () => setOpenAdd(false);
  const handleCloseAdd = () => setOpenAdd(false);


const postData = () => {
    setOpenAdd(false);
    axios.get(`http://localhost:8001/practiceProject/DeleteInvoice`, {
      params: {
        
      },
    });
  };

  const useStyle = makeStyles({
    field: {
      marginTop: 10,
      marginBottom: 10,
      width: 500,
      padding: "5px",
      margin: "5px",
    },
    input: {
      background: "rgb(232, 241, 250)",
      "&:hover": {
        background: "rgb(232, 241, 250)",
      },
    },
  });
  const classes = useStyle();
  

  return (
    <div>
      <Button
        onClick={() => setOpenAdd(true)}
        variant="outlined"
        color="primary"
        style={{ border: "2px solid #3f51b5", color: "white" }}
      >
        Delete
      </Button>
      <Dialog
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        style={{ display: "flex", flexDirection: "column", gap: "10vh" }}
      >
        <DialogTitle style={{ backgroundColor: "#39495e", color: "white" }}>
          Delete
        </DialogTitle>
        <DialogContent>
          <DialogContentText
            style={{ backgroundColor: "#39495e", color: "white" }}
          >
            Are you sure, want to Delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions
          style={{
            display: "flex",
            backgroundColor: "#39495e",
            color: "white",
            justifyContent: "center",
          }}
        >
          <div className="dbtn">
            <Button
              style={{ width: 200 }}
              variant="contained"
              onClick={handleCloseAdd}
            >
              Cancel
            </Button>
            &nbsp;&nbsp;
            <Button
              //onClick={postData}
              style={{ width: 200 }}
              variant="contained"
              type="submit"
            >
              Delete
            </Button>
          </div>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default DeleteInvoice;
