import React, { useEffect } from "react";
import { useState } from "react";
import { Typography } from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import axios from "axios";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";

function EditInvoice() {
  const useStyle = makeStyles({
    field: {
      marginTop: 10,
      marginBottom: 10,
      width: 500,
      padding: "5px",
      margin: "5px",
    },
    input: {
      background: "rgb(232, 241, 250)",
      "&:hover": {
        background: "rgb(232, 241, 250)",
      },
    },
  });
  const classes = useStyle();
  const [openAdd, setOpenAdd] = React.useState(false);
  const addClick = () => setOpenAdd(false);
  const handleCloseAdd = () => setOpenAdd(false);
  const [invoicecurrency, setinvoicecurrency] = useState("");
  const [customerpaymentterms, setcustomerpaymentterms] = useState("");

  const postEdit = () => {
    setOpenAdd(false);
    axios.get(`http://localhost:8001/practiceProject/AdvanceSearch`, {
      params: {
        invoicecurrency,
        customerpaymentterms,
      },
    });
  };
  return (
    <div>
      <Button
        onClick={() => setOpenAdd(true)}
        color="primary"
        style={{ width: "200", border: "2px solid #3f51b5", color: "white" }}
      >
        Edit
      </Button>
      <Dialog
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        style={{ display: "flex", flexDirection: "column", gap: "10vh" }}
      >
        <DialogTitle style={{ backgroundColor: "#39495e", color: "white" }}>
          EDIT
        </DialogTitle>
        <DialogContent
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "10vh",
            height: "80%",
            backgroundColor: "#39495e",
          }}
        >
          
            <div>
              <TextField
                margin="dense"
                className={classes.field}
                InputProps={{ className: classes.input }}
                backgroundColor="white"
                id="filled-basic"
                label="Invoice Currency"
                variant="filled"
                name="invoice_currency"
                style={{ width: 200 }}
                value={invoicecurrency}
                onChange={(e) => {
                  setinvoicecurrency(e.target.value);
                }}
              />
              <TextField
                id="filled-basic"
                className={classes.field}
                InputProps={{ className: classes.input }}
                label="Customer Payment Terms"
                variant="filled"
                style={{ width: 200 }}
                name="cust_payment_terms"
                value={customerpaymentterms}
                onChange={(e) => {
                  setcustomerpaymentterms(e.target.value);
                }}
              />
            </div>
        </DialogContent>
        <DialogActions
          style={{
            display: "flex",
            backgroundColor: "#39495e",
            color: "white",
            justifyContent: "center",
          }}
        >
          <div className="dbtn">
            <Button
              style={{ width: 200 }}
              variant="contained"
              onClick={handleCloseAdd}
            >
              CANCLE
            </Button>
            &nbsp;&nbsp;
            <Button
              //onClick={postData}
              style={{ width: 200 }}
              variant="contained"
              type="submit"
            >
              EDIT
            </Button>
          </div>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default EditInvoice;
