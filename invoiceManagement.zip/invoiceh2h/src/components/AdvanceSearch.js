import React, { useEffect } from "react";
import { useState } from "react";
import { Typography } from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import axios from "axios";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";

function AdvanceSearch() {
  const useStyle = makeStyles({
    field: {
      marginTop: 10,
      marginBottom: 10,
      width: 500,
      padding: "5px",
      margin: "5px",
    },
    input: {
      background: "rgb(232, 241, 250)",
      "&:hover": {
        background: "rgb(232, 241, 250)",
      },
    },
  });
  const classes = useStyle();
  const [openAdd, setOpenAdd] = React.useState(false);
  const addClick = () => setOpenAdd(false);
  const handleCloseAdd = () => setOpenAdd(false);
  const [documentId, setDocumentId] = useState("");
  const [invoiceId, setInvoiceId] = useState("");
  const [customerNumber, setcustomerNumber] = useState("");
  const [businessYear, setBusinessYear] = useState("");
  const postData = () => {
    setOpenAdd(false);
    axios
      .get(`http://localhost:8001/practiceProject/AdvanceSearch`, {
        params: {
          documentId,
          invoiceId,
          customerNumber,
          businessYear,
        },
      })
  };

  return (
    <div>
      <Button
        onClick={() => setOpenAdd(true)}
        variant="outlined"
        color="primary"
        style={{ border: "2px solid #3f51b5", color: "white" }}
      >
        Advance Search
      </Button>

      <form action="">
        <Dialog
          open={openAdd}
          onClose={() => setOpenAdd(false)}
          style={{ display: "flex", flexDirection: "column", gap: "10vh" }}
        >
          <DialogTitle style={{ backgroundColor: "#39495e", color: "white" }}>
            ADVANCE SEARCH
          </DialogTitle>
          <DialogContent
            style={{
              display: "flex",
              flexDirection: "column",
              backgroundColor: "#39495e",
            }}
          >
            <div>
              <div>
                <TextField
                  margin="dense"
                  className={classes.field}
                  InputProps={{ className: classes.input }}
                  backgroundColor="white"
                  id="filled-basic"
                  label="DocumentId"
                  variant="filled"
                  name="doc_id"
                  style={{ width: 200 }}
                  value={documentId}
                  onChange={(e) => {
                    setDocumentId(e.target.value);
                  }}
                />
                <TextField
                  id="filled-basic"
                  InputProps={{ className: classes.input }}
                  className={classes.field}
                  label="InvoiceId"
                  variant="filled"
                  style={{ width: 200 }}
                  name="invoice_id"
                  value={invoiceId}
                  onChange={(e) => {
                    setInvoiceId(e.target.value);
                  }}
                />
              </div>
              <div>
                <TextField
                  id="filled-basic"
                  className={classes.field}
                  InputProps={{ className: classes.input }}
                  label="CustomerNumber"
                  variant="filled"
                  style={{ width: 200 }}
                  name="cust_number"
                  value={customerNumber}
                  onChange={(e) => {
                    setcustomerNumber(e.target.value);
                  }}
                />

                <TextField
                  id="filled-basic"
                  InputProps={{ className: classes.input }}
                  className={classes.field}
                  label="BusinessYear"
                  variant="filled"
                  style={{ width: 200 }}
                  name="buisness_year"
                  value={businessYear}
                  onChange={(e) => {
                    setBusinessYear(e.target.value);
                  }}
                />
              </div>
            </div>
          </DialogContent>
          <DialogActions
            style={{
              display: "flex",
              backgroundColor: "#39495e",
              color: "white",
              justifyContent: "center",
            }}
          >
            <div className="dbtn">
              <Button
                style={{ width: 200 }}
                variant="contained"
                onClick={handleCloseAdd}
              >
                Cancel
              </Button>
              &nbsp;&nbsp;
              <Button
                onClick={postData}
                style={{ width: 200 }}
                variant="contained"
                type="submit"
              >
                Search
              </Button>
            </div>
          </DialogActions>
        </Dialog>
      </form>
    </div>
  );
}

export default AdvanceSearch;
