import React from "react";
import {useState} from 'react';
import { TextField } from "@material-ui/core";
import { Button, Box, ButtonGroup } from "@material-ui/core";
import RefreshIcon from '@mui/icons-material/Refresh';
import logo from "./images/logo.svg";
import logo1 from "./images/Group 20399.png";
import AddDialog from "./AddDialog";
import { Refresh } from "@mui/icons-material";
//import AdvanceSearch from "./AdvanceSearch";
import DeleteInvoice from "./DeleteInvoice";


function Navbar(props) {
  const [value, setValue] = useState("");
  const refresh = ()=>{
      // re-renders the component
      setValue({});
  }
  
  return (
    <>
      <div className="logo-flex">
        <div className="logo-item">
          <img className="imgs" src={logo1} alt="logo" />
        </div>
        <div className="logo-item">
          <img className="imgs" src={logo} alt="logo" />
        </div>
        <br />
        <div className="invoice-list">Invoice Management</div>
      </div>
    {/*  <div className="wrapper">
        <div className="button-container">
          <Box >
            <ButtonGroup
              variant="contained"
              aria-label="outlined primary button group"
            >
              <Button
                onClick={props.predictClick}
                variant="contained"
                color="primary"
                style={{ border: "2px solid #3f51b5", color: "white" }}
              >
                Predict
              </Button>
              <AdvanceSearch/>
              <Button
                //onClick={props.predictClick}
                variant="outlined"
                color="primary"
                style={{ border: "2px solid #3f51b5", color: "white" }}
              >
                Analytics View
              </Button>
              <button variant='outlined' onClick={refresh}><RefreshIcon/></button>

            </ButtonGroup>

          </Box>
          <div className="button-containerM">
            <TextField
              style={{ border: "2px solid", color: "white" }}
              label="Search invoice id"
              variant="filled"
              InputLabelProps={{className:"field__lable"}}
            />
          </div>
         
          <AddDialog/>
          <DeleteInvoice/>
          <div className="button-containerM">
            <Button
              //onClick={props.predictClick}
              variant="outlined"
              color="primary"
              style={{ border: "2px solid #3f51b5", color: "white" }}
            >
              Edit
            </Button>
          </div>
        </div>
      </div>*/}
    </>
  );
}

export default Navbar;
