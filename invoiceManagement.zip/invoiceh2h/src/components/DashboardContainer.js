import React from "react";
import { Paper, Button } from "@material-ui/core";
import DataTable from "./DataTable";
import Navbar from "./Navbar";
import AddDialog from "./AddDialog";


function DashboardContainer() {
  

  return (
    <>
    <Navbar/>

         
      <Paper
        style={{
          background:"transparent radial-gradient(closest-side at 50% 50%, #58677E 0%, #39495E 100%) 0% 0%",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          
          <DataTable />
        </div>
      </Paper>
    </>
  );
}

export default DashboardContainer;
