import './App.css';
import React from 'react';
import DashboardContainer from './components/DashboardContainer';

function App() {

  
  return (
    <>
      <DashboardContainer/>
    </>
  );
}

export default App;
